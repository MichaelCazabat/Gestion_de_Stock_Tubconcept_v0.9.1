package com.example.gestiondestocktubconcept.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.example.gestiondestocktubconcept.R;

public class liste_produits extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_produits);
    }

    /* ++propriétées++ */

    private EditText txt_input_categorie;
    private EditText txt_input_reference;
    private EditText txt_input_nom;
    private EditText txt_input_prix;
    private EditText txt_input_quantité;
    private EditText txt_input_description;
    private Button btn_ajouter;

    /* --propriétées-- */

    private void init(){

        /* ++initialisation des liens avece les objets graphiques++ */

        EditText txt_input_categorie = (EditText) findViewById(R.id.txt_input_categorie);
        EditText txt_input_reference = (EditText) findViewById(R.id.txt_input_reference);
        EditText txt_input_nom = (EditText) findViewById(R.id.txt_input_nom);
        EditText txt_input_prix = (EditText) findViewById(R.id.txt_input_prix);
        EditText txt_input_quantite = (EditText) findViewById(R.id.txt_input_quantité);
        EditText txt_input_description = (EditText) findViewById(R.id.txt_input_description);
        Button btn_ajouter = (Button) findViewById(R.id.constraint_layout);

        /* --initialisation des liens avece les objets graphiques-- */





    }
public void export (view view){

}



}